import { expect, test } from "@playwright/test";
import { InventoryPage } from "./pages/InventoryPage";
import { LoginPage } from "./pages/LoginPage";

test("login and view the inventory", async ({ page }) => {
  const loginPage = new LoginPage(page);
  const inventoryPage = new InventoryPage(page);

  await loginPage.goto();
  await loginPage.login("standard_user", "tta_secret");

  await expect(page).toHaveURL(/inventory/);
  await expect(inventoryPage.productTitle).toBeVisible();
  await expect(inventoryPage.addToCartButton).toBeVisible();
  await expect(inventoryPage.shoppingCartLink).toBeVisible();
});
