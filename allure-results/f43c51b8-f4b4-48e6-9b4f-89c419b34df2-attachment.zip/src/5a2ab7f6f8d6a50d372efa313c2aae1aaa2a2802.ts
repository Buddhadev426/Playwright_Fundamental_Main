import { Locator, Page } from '@playwright/test';

export class Cart{
    readonly page : Page;
    readonly removeButton : Locator;
    readonly emptyMessage : Locator;
    readonly continueshoppingBtn : Locator;
    readonly productTitle : Locator;
    readonly productCard : Locator;
    readonly addToCartButton : Locator;
    readonly cartLink : Locator;
    readonly checkoutLink : Locator;

    constructor(page : Page){
        this.page = page;
        this.removeButton = page.getByRole('button', {name : 'Remove'});
        this.emptyMessage = page.getByRole('paragraph');
        this.continueshoppingBtn = page.getByRole('link', {name : 'Continue Shopping'});
        this.productTitle = page.getByRole('link', {name : 'TTA Bike Light'});
        this.productCard = page.getByRole('article').filter({has : this.productTitle});
        this.addToCartButton = this.productCard.getByRole('button', {name : 'Add to cart'});
        this.cartLink = page.getByRole('link', {name : "Shopping cart"});;
        this.checkoutLink = page.getByRole('link', {name : 'Checkout'});
    }

    async cart(){
        await this.removeButton.click();
        await this.continueshoppingBtn.click();
        await this.addToCartButton.click();
        await this.cartLink.click();
        await this.checkoutLink.click();
    }

}